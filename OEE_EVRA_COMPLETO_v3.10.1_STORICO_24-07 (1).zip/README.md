# OEE Produzione Lauria – applicazione unificata

Unica applicazione Streamlit Poka-Yoke per:

- Comber – estrazione acquosa;
- EV200 – concentrazione;
- Spray Dryer – essiccazione;
- Mescole – gestione dei lotti e produttività di reparto;
- navigazione laterale separata per Comber, EV200, Spray Dryer e Mescole;
- ultimi dati visibili e correggibili dentro ogni macchina;
- gestione completa a eventi: apertura, prosecuzione e chiusura lotto, modifica, duplicazione ed eliminazione;
- copertura obbligatoria delle otto ore e corretta gestione del terzo turno;
- sezioni centralizzate Excel e Storico con filtro per macchina;
- target giornalieri e giorni produttivi modificabili dall'app;
- dashboard Production vs Target per Comber e Spray Dryer;
- dashboard OEE separata con i tre cruscotti;
- indicatori di processo OEE: mass yield media Comber e taglio medio Spray Dryer;
- sezione Production vs Target separata, posizionata dopo le tre macchine;
- modalità ingrandita per visualizzare il report produttivo a tutta pagina;
- logo EVRA nella barra laterale;
- anagrafiche modificabili di codici droga, semilavorati, prodotti finiti da miscelare e causali;
- backup e ripristino Excel.
- pianificazione Comber con vista settimanale di tutti i prodotti e semaforo per singola campagna: Programmato, In linea, Sotto ritmo, In ritardo o Completato;
- confronto Comber per prodotto tra kg ed estrazioni pianificate, kg ed estrazioni completate, avanzamento reale/atteso e lotti fuori pianificazione;
- EV200 collegato a uno o più lotti Comber dello stesso prodotto, con inserimento del solo concentrato finale e residuo secco finale.
- gestione Comber per singola estrazione, con numero estrazione e droga caricata;
- stato della lavorazione determinato automaticamente: in corso senza liquido/residuo, completata quando entrambi i dati sono presenti;
- prosecuzione delle estrazioni tra turni senza duplicare la droga caricata.
- pianificazione Mescole importabile dal gestionale (`CODART`, `DESART`, `QUANTITA`, `DATEVA`) con avanzamento Plan vs Actual;
- 381 codici di prodotto finito precaricati come suggerimenti e possibilità di aggiungere nuovi codici e descrizioni;
- lotto Mescole automaticamente in corso senza quantità finale e automaticamente chiuso quando la quantità viene inserita, anche nel turno successivo;
- calcolo di durata, ore-uomo e produttività in kg/ora-uomo; Mescole resta separato dall'OEE delle tre macchine di processo.
- dashboard dedicata Mescole con kg prodotti e pianificati, lotti completati/in corso, ore di lavorazione, ore-uomo, kg/ora-uomo e analisi giornaliera/per prodotto.
- target Mescole configurabili per kg/giorno e kg/ora-uomo, con raggiungimento calcolato sul periodo selezionato.
- pianificazione Mescole aggregata per settimana, con avanzamento reale vs atteso, stato In anticipo/In linea/In ritardo e identificazione dei lotti fuori pianificazione.
- importazione dello storico gestionale da Carico Produzione ed Esplosione commessa;
- storico Spray Dryer ricostruito dalle sole righe `ATOM`, utilizzando data, lotto, articolo e quantità caricata;
- storico Comber ricostruito dai lotti semilavorati `WSD` e `YSD` contenenti componenti `MDR`, con puro reale ottenuto sottraendo la maltodestrina dal prodotto secco;
- importazioni ripetibili senza duplicazioni: lo storico gestionale precedente viene sostituito e i dati manuali hanno priorità.

## Pubblicazione su Streamlit Community Cloud

1. Creare o aprire un repository GitHub.
2. Caricare **il contenuto della cartella**, mantenendo anche `.streamlit/config.toml`.
3. In Streamlit Cloud selezionare il repository, il ramo `main` e `app.py`.
4. Fare clic su Deploy.

## Formule principali

- Comber: se la resa è inferiore al 15%, equivalente = kg droga × 15%; altrimenti equivalente = puro reale.
- Spray Dryer: equivalente 40% = minore tra semilavorato fisico e puro/40%; con tagli inferiori al 60% resta il dato fisico reale.
- Qualità OEE standard temporanea: 95%.

## Target

- Comber: 150 kg/giorno, 220 giorni/anno.
- EV200: 168,75 kg/giorno, 220 giorni/anno.
- Spray Dryer: 321,6 kg semilavorato/giorno e 128,64 kg equivalenti/giorno.

Scaricare regolarmente il backup Excel dalla pagina **Import / Export**.
